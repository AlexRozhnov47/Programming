double firstNorm(double [10][10], int n, int m);
double secondNorm(double [10][10], int n, int m);
double thirdNorm(double [10][10], int n, int m);